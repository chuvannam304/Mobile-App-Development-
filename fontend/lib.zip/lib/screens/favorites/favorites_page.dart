import 'package:flutter/material.dart';

import '../../services/favorite_service.dart';

class FavoritesPage extends StatefulWidget {
  const FavoritesPage({super.key});

  @override
  State<FavoritesPage> createState() => _FavoritesPageState();
}

class _FavoritesPageState extends State<FavoritesPage> {
  final FavoriteService favoriteService = FavoriteService();

  bool isLoading = true;
  List<dynamic> favorites = [];

  @override
  void initState() {
    super.initState();
    loadFavorites();
  }

  Future<void> loadFavorites() async {
    final data = await favoriteService.getFavorites();

    if (!mounted) return;

    setState(() {
      favorites = data;
      isLoading = false;
    });
  }

  String getText(dynamic item, String key) {
    if (item == null) return "";
    if (item[key] == null) return "";
    return item[key].toString();
  }

  dynamic getProduct(dynamic item) {
    return item["product"] ?? {};
  }

  String getImage(dynamic product) {
    final image =
        product["imageUrl"] ??
        product["image"] ??
        product["thumbnail"] ??
        "";

    return image.toString();
  }

  double getPrice(dynamic product) {
    final value =
        product["salePrice"] ??
        product["price"] ??
        product["comparePrice"] ??
        0;

    if (value is num) return value.toDouble();

    return double.tryParse(value.toString()) ?? 0;
  }

  String getProductName(dynamic product) {
    return (product["productName"] ??
            product["name"] ??
            product["title"] ??
            "Product")
        .toString();
  }

  String getBrand(dynamic product) {
    return (product["brand"] ?? product["brandName"] ?? "Brand").toString();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF9F9F9),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF9F9F9),
        elevation: 0,
        automaticallyImplyLeading: false,
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 16),
            child: Icon(Icons.search, color: Colors.black),
          ),
        ],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 8, 16, 8),
            child: Text(
              "Favorites",
              style: TextStyle(
                fontSize: 34,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
          ),

          SizedBox(
            height: 36,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: const [
                _ChipText(text: "Summer"),
                _ChipText(text: "T-Shirts"),
                _ChipText(text: "Shirts"),
                _ChipText(text: "New"),
              ],
            ),
          ),

          const SizedBox(height: 8),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: const [
                Icon(Icons.filter_list, size: 18),
                SizedBox(width: 6),
                Text("Filters", style: TextStyle(fontSize: 12)),
                Spacer(),
                Icon(Icons.swap_vert, size: 18),
                SizedBox(width: 6),
                Text(
                  "Price: lowest to high",
                  style: TextStyle(fontSize: 12),
                ),
                Spacer(),
                Icon(Icons.view_list, size: 18),
              ],
            ),
          ),

          const SizedBox(height: 12),

          Expanded(
            child: isLoading
                ? const Center(
                    child: CircularProgressIndicator(
                      color: Color(0xFFDB3022),
                    ),
                  )
                : favorites.isEmpty
                    ? const Center(
                        child: Text(
                          "No favorites yet",
                          style: TextStyle(color: Colors.grey),
                        ),
                      )
                    : RefreshIndicator(
                        color: const Color(0xFFDB3022),
                        onRefresh: loadFavorites,
                        child: ListView.builder(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          itemCount: favorites.length,
                          itemBuilder: (context, index) {
                            final item = favorites[index];
                            final product = getProduct(item);

                            return _FavoriteItem(
                              image: getImage(product),
                              brand: getBrand(product),
                              name: getProductName(product),
                              color: getText(item, "colorText"),
                              size: getText(item, "sizeText"),
                              price: getPrice(product),
                            );
                          },
                        ),
                      ),
          ),
        ],
      ),
    );
  }
}

class _ChipText extends StatelessWidget {
  final String text;

  const _ChipText({required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 30,
      margin: const EdgeInsets.only(right: 8),
      padding: const EdgeInsets.symmetric(horizontal: 18),
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: Colors.black,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Text(
        text,
        style: const TextStyle(color: Colors.white, fontSize: 12),
      ),
    );
  }
}

class _FavoriteItem extends StatelessWidget {
  final String image;
  final String brand;
  final String name;
  final String color;
  final String size;
  final double price;

  const _FavoriteItem({
    required this.image,
    required this.brand,
    required this.name,
    required this.color,
    required this.size,
    required this.price,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 116,
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Stack(
        children: [
          Row(
            children: [
              ClipRRect(
                borderRadius: const BorderRadius.horizontal(
                  left: Radius.circular(8),
                ),
                child: image.isNotEmpty
                    ? Image.asset(
                        "assets/images/$image",
                        width: 104,
                        height: 116,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) {
                          return Container(
                            width: 104,
                            height: 116,
                            color: Colors.grey.shade300,
                            child: const Icon(Icons.image),
                          );
                        },
                      )
                    : Container(
                        width: 104,
                        height: 116,
                        color: Colors.grey.shade300,
                        child: const Icon(Icons.image),
                      ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(12, 10, 34, 8),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        brand,
                        style: const TextStyle(
                          color: Colors.grey,
                          fontSize: 10,
                        ),
                      ),
                      Text(
                        name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Text(
                            "Color: ",
                            style: TextStyle(
                              color: Colors.grey.shade600,
                              fontSize: 11,
                            ),
                          ),
                          Text(color, style: const TextStyle(fontSize: 11)),
                          const SizedBox(width: 14),
                          Text(
                            "Size: ",
                            style: TextStyle(
                              color: Colors.grey.shade600,
                              fontSize: 11,
                            ),
                          ),
                          Text(size, style: const TextStyle(fontSize: 11)),
                        ],
                      ),
                      const Spacer(),
                      Row(
                        children: [
                          Text(
                            "\$${price.toStringAsFixed(0)}",
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                            ),
                          ),
                          const SizedBox(width: 18),
                          ...List.generate(
                            5,
                            (index) => const Icon(
                              Icons.star,
                              size: 14,
                              color: Color(0xFFFFBA49),
                            ),
                          ),
                          const Text(
                            "(0)",
                            style: TextStyle(
                              color: Colors.grey,
                              fontSize: 10,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),

          const Positioned(
            top: 8,
            right: 10,
            child: Icon(Icons.close, size: 18, color: Colors.grey),
          ),

          Positioned(
            right: 8,
            bottom: 8,
            child: Container(
              width: 36,
              height: 36,
              decoration: const BoxDecoration(
                color: Color(0xFFDB3022),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.shopping_bag_outlined,
                color: Colors.white,
                size: 19,
              ),
            ),
          ),
        ],
      ),
    );
  }
}