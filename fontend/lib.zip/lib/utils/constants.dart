// class Constants {
//   static const String baseUrl = "http://192.168.1.14:8080/api/auth";
// }
// class Constants {
//   static const String baseUrl = "http://localhost:8080/api/auth";
// }
class Constants {
  static const String baseUrl = "http://192.168.1.6:8080/api/auth";

  static const String apiUrl = "http://192.168.1.6:8080/api";
}